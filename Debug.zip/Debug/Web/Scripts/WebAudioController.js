﻿<script src="scripts/jquery-1.6.4.js"></script>
    <script>
    $( "#submit" ).click(function() {
        alert("Handler for .click() called.");
  });
</script>